package es.unex.propuesta_proyecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CrearCuenta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);
    }
}